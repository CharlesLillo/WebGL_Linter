function main(){
         gl.clearColor(0.0, 0.0, 0.0, 1.0);
}