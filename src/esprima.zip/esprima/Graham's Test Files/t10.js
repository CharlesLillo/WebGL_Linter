function main(){
        gl.bindBuffer(gl.ARRAY_BUFFER, laptopVertexPositionBuffer);
}