function main(){
        gl.enable(gl.DEPTH_TEST);
}